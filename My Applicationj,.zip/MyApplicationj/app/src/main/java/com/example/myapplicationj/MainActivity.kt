package com.example.myapplicationj

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    var listMot: MutableList<String> = mutableListOf("Why","When,'Whom","Where","What")

    override fun onCreate(savedInstanceState: Bundle?) {
        var points:Int = 0
        var motAleat:String
        var mot:String
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        while(true){
            score.text = "Votre score est : "+points
            motAleat = randomExtract(listMot)
            mot = editText.toString()
            if(mot == motAleat){
                points = points+5
                textView2.text = "Bravo !!! Vous avez obtenu 5 points"
            }
            else{
                textView2.text = "Echec !!! Le mot saisi n'est pas bon"
            }
        }

    }

    fun randomExtract(liste:List<String>):String{
        var i = (0..liste.size).random()
        return liste[i]
    }

}
