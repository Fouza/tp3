package com.example.myapplicationj

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main2.*



data class Prod(val name:String, val price:Long, var qte:Int)

class MyAdapter(private val data: List<Prod>) :
    RecyclerView.Adapter<MyAdapter.MyViewHolder>() {

abstract class Product(val name:String, val price:Long, var qte: Int)
{
    abstract fun getType() : String
}
class Pack (   name: String,
               price: Long,
               qte: Int,
               val giftName: String,
               val giftQte: Int,
               val smartphones: List<Smartphone> )
    : Product (
    name,
    price,
    qte
) {
    override fun getType(): String {
        return "Pack"
    }
}

class Smartphone (
    name: String,
    price: Long,
    qte: Int,
    val brand: String,
    val model: String,
    val color: String,
    val qtePhone: Int?
) : Product (
    name,
    price,
    qte
) {
    override fun getType(): String {
        return "Smartphone"
    }
}

class Main2Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        val phone =  Smartphone(name = "LG 340", price = 30, qte = 3, brand = "LG", model = "LG", color = "Black", qtePhone = 2);
        val pack = Pack(
            name = "Premium pack",
            price = 230,
            qte = 3,
            giftName = "Alpha gift",
            giftQte = 2,
            smartphones = listOf<Smartphone>(
                Smartphone(name = "iPhone 8", price = 30,qte = 3,brand = "Apple", model = "iPhone", color = "Black", qtePhone = 2),
                Smartphone( name = "LG 340", price = 30, qte = 3,brand = "LG", model = "LG", color = "Black",qtePhone = 2)));

        displayProduct(phone)
    }

    fun displayProduct(product:Product){
        qte.text = product.qte.toString()
        price.text = product.price.toString()
        name.text = product.name
    }

}



